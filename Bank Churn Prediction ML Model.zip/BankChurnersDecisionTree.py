# Bank Churn Prediction (Decision Tree)
# Name: Jay Parekh            Student ID: S14140141           Tutor: Yevgeniya Kovalchuk
# CMP6202 Artificial Intelligence and Machine Learning


# Import libraries and functions.

# To manipulate the data set as a data frame, import pandas.
import pandas as pd

# For management and plotting histograms, import MatplotLib.
import matplotlib.pyplot as plt

# For plotting bar charts, heat maps and box plots, import seaborn.
import seaborn as sns

# Import the following libraries, for slicing, cross validating and tuning, respectively.
from sklearn.model_selection import train_test_split, cross_val_score, RandomizedSearchCV

# Import StandardScaler to apply feature scaling to the dataset, to normalize values.
from sklearn.preprocessing import StandardScaler

# Import the DecisionTreeClassifier model from the SciKit-Learn tree directory, for use in the model.
from sklearn.tree import DecisionTreeClassifier

# Import the classification report, accuracy score and confusion matrix functions, to evaluate the model.
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Import the pprint function, to print python data structures as inputs.
from pprint import pprint


# Obtain the data.

# Define and import the dataset.
customer_dataset = pd.read_csv(r'BankChurners.csv')

# Preview the first 5 rows of the dataset.
print('Data frame preview:')
print(customer_dataset.head())


# Clean the data.

# Verify that there are no null values.
print("\n Null value count:")
print(customer_dataset.isnull().sum())
# Drop rows with null values, if any.
customer_dataset = customer_dataset.dropna(axis=0)
# Create a new dataset, removing any columns deemed unnecessary by initial observation.
dataset = customer_dataset.drop(['CLIENTNUM','Naive_Bayes_Classifier_Attrition_Flag_Card_Category_Contacts_Count_12_mon_Dependent_count_Education_Level_Months_Inactive_12_mon_1',
                                 'Naive_Bayes_Classifier_Attrition_Flag_Card_Category_Contacts_Count_12_mon_Dependent_count_Education_Level_Months_Inactive_12_mon_2'],
                                axis = 1)
# Preview the dataset, to verify the removed columns.
print(dataset.head())


# Inspect the data.

# Show the attributes of the dataset, to find the categorical variables.
print(dataset.info())
print(dataset.describe())

# Use the value_counts function to count the number of variables in each categorial column.
print(dataset['Attrition_Flag'].value_counts())
print(dataset['Gender'].value_counts())
print(dataset['Education_Level'].value_counts())
print(dataset['Marital_Status'].value_counts())
print(dataset['Income_Category'].value_counts())
print(dataset['Card_Category'].value_counts())


# Preprocess the data.

# Classify the ordinal variables.
ordinal_variables = {'Education_Level': {'Unknown':0, 'Uneducated':1, 'High School':2, 'College':3, 
                                  'Graduate':4, 'Post-Graduate':5, 'Doctorate':6},
              'Income_Category': {'Unknown':0, 'Less than $40K':1, '$40K - $60K':2,
                                  '$60K - $80K':3, '$80K - $120K':4,'$120K +':5},
              'Card_Category': {'Blue':0, 'Silver':1, 'Gold':2, 'Platinum':3}
             }

# Replace the ordinal, textural columns with the ordinal, numbered variables.
dataset = dataset.replace(ordinal_variables)

# Isolate the categorical attributes from the dataset for conversion to numeric.
dataset =  dataset.drop(['Attrition_Flag', 'Gender','Marital_Status'], axis=1)

# Use the get_dummies function to convert the remaining categories to binary variables.
# Use the .iloc[] function to remove unnecessary columns for binary identifiers.
Attrition_Flag = pd.get_dummies(customer_dataset.Attrition_Flag)
Gender = pd.get_dummies(customer_dataset.Gender).iloc[:,1:]
Marital_Status = pd.get_dummies(customer_dataset.Marital_Status)

# Concatenate the nominal, numerically transformed data with the original dataset.
dataset = pd.concat([dataset,Attrition_Flag,Gender,Marital_Status], axis=1)

# Remove unnecessary columns.
dataset = dataset.drop(['Existing Customer'], axis = 1)

# Verify that the columns have been encoded by previewing the dataset.
print(dataset.head())


# Visualize the data.

# Plot a bar chart showing the balance of the label data.
fig = plt.subplots(figsize=(5,5))
sns.countplot(x='Attrited Customer', data=dataset)
plt.title("Attrition Status")
plt.show()

# Use the corr function to calculate the correlations within the dataset, and define them for use in a heatmap.
corrdata = dataset.corr()

# Plot a heatmap to show the correlation of the data within the dataset.
fig = plt.subplots (figsize = (20,20))
plt.title("Correlation heatmap")
sns.heatmap(corrdata)
plt.show()

# Plot histograms, showing the distribution of each of the variables.
plt.rcParams['figure.figsize'] = (20,20)
dataset.hist(bins=100)

# Plot a box plot showing the effect of total transaction amount on attrition.
fig = plt.subplots(1, figsize=(5, 5))
sns.boxplot(x = 'Attrited Customer', y = 'Total_Trans_Amt', data = dataset)
plt.title("The effect of total transaction amount on attrition")
plt.show()

# Plot a box plot showing the effect of total transaction count on attrition.
fig = plt.subplots(1, figsize=(5, 5))
sns.boxplot(x = 'Attrited Customer', y = 'Total_Trans_Ct', data = dataset)
plt.title("The effect of total transaction count on attrition")
plt.show()

# Plot a box plot showing the effect of average utilization ratio on attrition.
fig = plt.subplots(1, figsize=(5, 5))
sns.boxplot(x = 'Attrited Customer', y = 'Avg_Utilization_Ratio', data = dataset)
plt.title("The effect of average utilization ratio on attrition")
plt.show()

# Plot a bar chart showing the effect of Gender on attrition.
fig = plt.subplots(figsize=(5,5))
sns.countplot(x='Attrition_Flag', data=customer_dataset, hue='Gender')
plt.title("The effect of gender on attrition")
plt.show()

# Plot a bar chart showing the effect of income categories on attrition.
fig = plt.subplots(figsize=(5,5))
sns.countplot(x='Attrited Customer', data=dataset, hue='Income_Category')
plt.title("The effect of income categories on attrition")
plt.show()

# Plot a bar chart showing the effect of marital status on attrition.
fig = plt.subplots(figsize=(5,5))
sns.countplot(x='Attrition_Flag', data=customer_dataset, hue='Marital_Status')
plt.title("The effect of marital status on attrition")
plt.show()

# Plot a bar chart showing the effect of dependencies on attrition.
fig = plt.subplots(figsize=(5,5))
sns.countplot(x='Attrited Customer', data=dataset, hue='Dependent_count')
plt.title("The effect of dependencies on attrition")
plt.show()


# Data slicing.

# Set the feature set, X and label set, y, by isolating the label set from the feature set, X and setting the label set as y.
X0 =  dataset.drop(['Attrited Customer'], axis=1)
y = dataset['Attrited Customer']

# Define StandardScaler and apply the scaler transform to the feature sets.
featurescaler = StandardScaler()
X = featurescaler.fit_transform(X0)

# Split the X and y datasets to train and test sets, with a 20% split of the data used for the test set.
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)


# Algorithm fitting and evaluation.

# Build the model using the decision tree algorithm.

# Configure the model parameters.
classifier = DecisionTreeClassifier()  

# Define the feature set and label set for training the classifier.
classifier.fit(X_train, y_train) 

# Define the feature set for testing for generating predictions.
predictions = classifier.predict(X_test)

# Model evaluation using performance metrics.

# Calculate the accuracy score of the classifier, using the 'accuracy_score' function.
print('\n Accuracy score:')
print(accuracy_score(y_test, predictions))

# View the cross validation scores prior to hyperparameter tuning.
orig_cv_scores = cross_val_score(estimator = classifier, X = X0, y=y, cv = 10)

# Plot a box plot showing the cross valdation scores obtained.
fig = plt.subplots(1, figsize=(5, 5))
sns.boxplot(data = orig_cv_scores)
plt.title("Intitial Cross Validation Scores DT")
plt.show()

# Generate the classification report for the classifier, using the 'classification_report' and 'print' functions.
print('\n Classification report:')
print(classification_report(y_test,predictions ))

# Calculate and show the confusion matrix using the label and prediction data.
ConfMatrix = confusion_matrix(y_test,predictions)
print('\n Confusion matrix:')
print(ConfMatrix)

# Show the confusion matrix as a heat map, for better visualization.
sns.heatmap(ConfMatrix, annot=True)
plt.title("Decision Tree Confusion Matrix")

# Obtain and display the parameters used for the decision tree classifier using the pprint function.
print('\n Active parameters:\n')
pprint(classifier.get_params())


# Obtain the key features, using the feature_importances function, selecting the feature set as the data.
# Define the data as 'keyfeatures'.
keyfeatures = pd.Series(classifier.feature_importances_, index=X0.columns)

# Use 'keyfeatures' to display the top 10 'nlargest' features, adding a title to the plot
keyfeatures.nlargest(10).plot(kind='barh')
plt.title("Key features affecting Churn")


# Hyperparameter tuning and evaluation.

# Setup the parameters and distributions to sample from: param_dist
param_dist = {"max_depth": [5, 7, 10, 15, None],
              "max_features": ('auto', 'sqrt'),
              "min_samples_leaf": (1, 2, 4),
              "criterion": ["gini", "entropy"]}

# Call and define the decision tree model. 
tree = DecisionTreeClassifier()

# Use the RandomizedSearchCV function upon the decision tree, defining it as 
# "tree_cv".
tree_cv = RandomizedSearchCV(tree, param_dist, cv=10)

# Fit the randomized tree to the data.
tree_cv.fit(X_train, y_train)

# View the optimal parameters.
print('\n Optimal parameters:')
print(tree_cv.best_params_)

# View the mean cross validation score of the hyperparameter tuning.
print("\n Mean CV score:")
print(tree_cv.best_score_)

# Calculate the percentage improvement over the original model parameters.
# As shown, there is an improvement of 0.749% using RandomizedSearchCV.
print("\n Percentage improvement using RandomizedSearchCV")
print(((tree_cv.best_score_-accuracy_score(y_test, predictions ))/accuracy_score(y_test, predictions ))*100)


# Visualizing the mean cross validation scores.

# Obtain the array of cross validation results, as a table using '.cv_results_'
tuned_results = tree_cv.cv_results_

# Use the "DataFrame" function to convert the array of results to a dataframe defined as 'Tuned_Results', previewing the results.
Tuned_Results = pd.DataFrame(tuned_results)
print("\n Tuned Cross Validation results:")
print(Tuned_Results.head())

# Plot a box plot showing the  mean cross valdation scores obtained.
fig = plt.subplots(1, figsize=(5, 5))
sns.boxplot(data = Tuned_Results, y = 'mean_test_score')
plt.title("Tuned Mean CV Scores DT")
plt.show()


